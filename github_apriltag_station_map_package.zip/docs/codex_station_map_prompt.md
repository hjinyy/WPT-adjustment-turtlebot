# Codex Prompt: Switch WPT Alignment to PDF Station Map

아래 내용을 Codex/Antigravity 입력창에 그대로 붙여넣어 사용하면 됩니다.

```text
We decided to use the existing apriltag_sheet.pdf marker IDs as-is instead of generating new 111/112/113/114-style AprilTag IDs.

Important correction:
Do not generate new AprilTag images using 111/112/113/114 for the full floor layout.
Use the numeric marker IDs already printed in apriltag_sheet.pdf.

The labels such as A02N, A02E, A02S, A02W are human-readable station labels.
The AprilTag detector returns the numeric marker ID written in the PDF, such as marker 5, 6, 7, 8.

Please update the existing code/config/docs to support this station_map layout.

Keep the pair-based alignment logic that was already implemented:
- pair midpoint
- pair angle
- stable_count
- safe dry_run behavior
- zero command when one marker in the pair is missing

But change the marker ID selection layer from the previous shelf convention to this explicit station map.

Use this mapping from docs/apriltag_marker_map.md and docs/apriltag_sheet.pdf.

Floor node markers:
- A01 = 1
- B01 = 2
- C01 = 3
- D01 = 4
- D02 = 17
- A03 = 18
- B03 = 19
- C03 = 20
- D04 = 37
- A05 = 38
- B05 = 39
- C05 = 40
- D05 = 41

Station/workspace markers:

A02:
- north = 5
- east  = 6
- south = 7
- west  = 8

B02:
- north = 9
- east  = 10
- south = 11
- west  = 12

C02:
- north = 13
- east  = 14
- south = 15
- west  = 16

D03:
- north = 21
- east  = 22
- south = 23
- west  = 24

A04:
- north = 25
- east  = 26
- south = 27
- west  = 28

B04:
- north = 29
- east  = 30
- south = 31
- west  = 32

C04:
- north = 33
- east  = 34
- south = 35
- west  = 36

Implementation requirements:

1. Add station-map-based ID lookup in the existing tag layout module.
   Suggested helpers:
   - station_tag_id(station_name, position)
   - station_pair_ids(station_name, pair_name)
   - decode_station_tag(tag_id)

2. Keep the existing shelf-based 111/112 convention only if useful for backwards compatibility, but station_map should become the recommended/default mode for the current physical tag sheet.

3. Update config/wpt_alignment.yaml so that it can use:
   - layout_mode: station_map
   - target_station: A02
   - final_pair: west_east
   - rotation_verify_pair: north_south

4. For station_map mode:
   - target_station=A02 and final_pair=west_east should use marker IDs 8 and 6.
   - target_station=A02 and rotation_verify_pair=north_south should use marker IDs 5 and 7.
   - target_station=B02 and final_pair=west_east should use marker IDs 12 and 10.
   - target_station=C04 and rotation_verify_pair=north_south should use marker IDs 33 and 35.

5. Update wpt_alignment_node.py so that pair selection uses station_pair_ids() when layout_mode is station_map.

6. Keep dry_run true by default.
   Do not enable real /cmd_vel.
   Do not SSH into the robot.
   Do not run robot motion commands.

7. Update logs to show:
   - layout_mode
   - target_station
   - selected_pair
   - required numeric marker IDs
   - visible marker IDs
   - pair_mid_x
   - pair_mid_y
   - pair_angle_deg
   - x_error
   - y_error
   - angle_error
   - stable_count

8. Update docs/README to explain:
   - We are using apriltag_sheet.pdf as the physical marker sheet.
   - The detector returns numeric marker IDs.
   - A02N means station A02 north marker, but the actual detected ID is 5.
   - For WPT final alignment, west_east pair is used.
   - For A02, west_east pair means marker 8 and marker 6.

9. Update tests:
   Add tests for:
   - station_tag_id("A02", "north") == 5
   - station_tag_id("A02", "east") == 6
   - station_tag_id("A02", "south") == 7
   - station_tag_id("A02", "west") == 8
   - station_pair_ids("A02", "west_east") == (8, 6)
   - station_pair_ids("A02", "north_south") == (5, 7)
   - station_pair_ids("B02", "west_east") == (12, 10)
   - station_pair_ids("C04", "north_south") == (33, 35)
   - decode_station_tag(6) returns A02/east or an equivalent structure

10. Do not remove the pair alignment math.
    Only change how the required marker IDs are selected.

After editing, run:
python3 -m pytest -q
python3 -m py_compile wpt_adjustment_turtlebot/tag_layout.py
python3 -m py_compile wpt_adjustment_turtlebot/wpt_alignment_node.py

After the update, tell me the exact dry-run command to test A02 west/east alignment.
```
