# AprilTag Marker Map for WPT TurtleBot

이 문서는 실제 바닥에 부착할 `apriltag_sheet.pdf`의 마커 라벨과 AprilTag detector가 반환하는 **numeric marker ID**를 정리한 기준 문서입니다.

## 핵심 결정

현재 실험에서는 새로 `111, 112, 113, 114` 형태의 태그를 다시 생성하지 않고, 기존 `apriltag_sheet.pdf`에 인쇄된 numeric marker ID를 그대로 사용합니다.

중요한 점은 다음과 같습니다.

- `A02N`, `A02E`, `A02S`, `A02W`는 사람이 보기 위한 station label입니다.
- 실제 AprilTag detector가 반환하는 값은 `marker 5`, `marker 6`, `marker 7`, `marker 8` 같은 numeric ID입니다.
- 따라서 코드에서는 `target_station=A02`와 `final_pair=west_east`를 설정하면 실제 required marker IDs가 `(8, 6)`이 되도록 해야 합니다.
- 기존의 shelf 기반 `111/112/113/114` helper는 필요하면 legacy/helper로 남겨둘 수 있지만, 실제 물리 태그 시트 기반 실험 기본값은 `station_map`을 권장합니다.

## Pair convention

Pair 이름은 기존 pair-based WPT alignment 로직과 동일하게 유지합니다.

| Pair name | 구성 | 용도 |
|---|---|---|
| `west_east` | west + east | 최종 WPT 코일 정합 기본 pair |
| `north_south` | north + south | 90도 회전 후 방향 검증용 pair |

주의: pair의 순서는 기존 코드의 angle 정의와 일관되게 유지해야 합니다. 이 문서에서는 `west_east = (west, east)`, `north_south = (north, south)` 순서로 표기합니다.

---

## Station / workspace markers

### A02

| Human label | Position | Numeric marker ID |
|---|---|---:|
| A02N | north | 5 |
| A02E | east | 6 |
| A02S | south | 7 |
| A02W | west | 8 |

Pair IDs:

| Pair | Required numeric marker IDs |
|---|---|
| `west_east` | `(8, 6)` |
| `north_south` | `(5, 7)` |

### B02

| Human label | Position | Numeric marker ID |
|---|---|---:|
| B02N | north | 9 |
| B02E | east | 10 |
| B02S | south | 11 |
| B02W | west | 12 |

Pair IDs:

| Pair | Required numeric marker IDs |
|---|---|
| `west_east` | `(12, 10)` |
| `north_south` | `(9, 11)` |

### C02

| Human label | Position | Numeric marker ID |
|---|---|---:|
| C02N | north | 13 |
| C02E | east | 14 |
| C02S | south | 15 |
| C02W | west | 16 |

Pair IDs:

| Pair | Required numeric marker IDs |
|---|---|
| `west_east` | `(16, 14)` |
| `north_south` | `(13, 15)` |

### D03

| Human label | Position | Numeric marker ID |
|---|---|---:|
| D03N | north | 21 |
| D03E | east | 22 |
| D03S | south | 23 |
| D03W | west | 24 |

Pair IDs:

| Pair | Required numeric marker IDs |
|---|---|
| `west_east` | `(24, 22)` |
| `north_south` | `(21, 23)` |

### A04

| Human label | Position | Numeric marker ID |
|---|---|---:|
| A04N | north | 25 |
| A04E | east | 26 |
| A04S | south | 27 |
| A04W | west | 28 |

Pair IDs:

| Pair | Required numeric marker IDs |
|---|---|
| `west_east` | `(28, 26)` |
| `north_south` | `(25, 27)` |

### B04

| Human label | Position | Numeric marker ID |
|---|---|---:|
| B04N | north | 29 |
| B04E | east | 30 |
| B04S | south | 31 |
| B04W | west | 32 |

Pair IDs:

| Pair | Required numeric marker IDs |
|---|---|
| `west_east` | `(32, 30)` |
| `north_south` | `(29, 31)` |

### C04

| Human label | Position | Numeric marker ID |
|---|---|---:|
| C04N | north | 33 |
| C04E | east | 34 |
| C04S | south | 35 |
| C04W | west | 36 |

Pair IDs:

| Pair | Required numeric marker IDs |
|---|---|
| `west_east` | `(36, 34)` |
| `north_south` | `(33, 35)` |

---

## Floor node markers

아래 floor node marker들은 WPT 최종 코일 정합 pair에는 직접 사용하지 않습니다. 이후 경로 트래킹, node-based navigation, station entry trigger 등에 사용할 수 있습니다.

| Node label | Numeric marker ID | Type |
|---|---:|---|
| A01 | 1 | floor node |
| B01 | 2 | floor node |
| C01 | 3 | floor node |
| D01 | 4 | floor node |
| D02 | 17 | floor node |
| A03 | 18 | floor node |
| B03 | 19 | floor node |
| C03 | 20 | floor node |
| D04 | 37 | floor node |
| A05 | 38 | floor node |
| B05 | 39 | floor node |
| C05 | 40 | floor node |
| D05 | 41 | floor node |

---

## Recommended config mode

`config/wpt_alignment.yaml`에는 다음과 같은 개념이 들어가야 합니다.

```yaml
layout:
  mode: station_map
  target_station: A02

alignment:
  final_pair: west_east
  rotation_verify_pair: north_south
```

또는 기존 config 구조에 맞춰 다음과 같은 key 이름을 사용할 수 있습니다.

```yaml
layout_mode: station_map
target_station: A02
alignment:
  final_pair: west_east
  rotation_verify_pair: north_south
```

중요한 것은 `station_map` mode에서 다음이 성립해야 한다는 점입니다.

```text
target_station=A02, final_pair=west_east      -> required IDs = (8, 6)
target_station=A02, rotation_verify_pair=north_south -> required IDs = (5, 7)
target_station=B02, final_pair=west_east      -> required IDs = (12, 10)
target_station=C04, rotation_verify_pair=north_south -> required IDs = (33, 35)
```

---

## Dry-run example

A02 station의 west/east pair를 dry-run으로 확인하는 예시입니다.

```bash
ros2 run wpt_adjustment_turtlebot wpt_alignment_node \
  --ros-args \
  -p config_file:=$(pwd)/config/wpt_alignment.yaml \
  -p layout_mode:=station_map \
  -p target_station:=A02 \
  -p dry_run:=true
```

정상 로그 예시는 다음과 같아야 합니다.

```text
layout_mode=station_map
target_station=A02
selected_pair=west_east
required_ids=(8, 6)
visible_ids=[8, 6]
pair_mid_x=...
pair_mid_y=...
pair_angle_deg=...
x_error=...
y_error=...
angle_error=...
stable_count=...
```

한쪽 마커만 보이면 다음처럼 안전 정지 상태가 되어야 합니다.

```text
pair_missing
required_ids=(8, 6)
stable_count=0
cmd linear.x=0.0000 angular.z=0.0000
```

---

## Physical placement note

AprilTag는 회전되어 있어도 numeric ID는 인식될 수 있습니다. 하지만 WPT 정합에서는 pair angle과 calibration target을 사용하므로, 마커 부착 방향을 일관되게 유지해야 합니다.

권장 규칙:

```text
각 마커는 그 마커를 인식할 카메라 기준으로 화면에서 upright하게 보이도록 바닥에 부착한다.
```

최종 WPT 정합은 `west_east` pair를 사용하고, 90도 회전 후 방향 검증은 `north_south` pair를 사용합니다.
