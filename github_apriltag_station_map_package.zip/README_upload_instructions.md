# GitHub Upload Instructions

아래 파일들을 기존 `WPT-adjustment-turtlebot` 레포에 추가해서 GitHub branch로 push하면 됩니다.

## 넣을 위치

```text
docs/apriltag_sheet.pdf
docs/apriltag_marker_map.md
docs/codex_station_map_prompt.md
config/station_map_reference.yaml
```

## 권장 작업 순서

```bash
cd ~/Coilmodel/WPT-adjustment-turtlebot
mkdir -p docs config

# 이 패키지 안의 파일들을 위 경로에 복사한 뒤 확인
git status
git diff --stat
```

새 branch를 만들어 push하는 것을 권장합니다.

```bash
git switch -c feature/station-map-apriltags
git add docs/apriltag_sheet.pdf docs/apriltag_marker_map.md docs/codex_station_map_prompt.md config/station_map_reference.yaml
git commit -m "Add AprilTag station map documentation"
git push -u origin feature/station-map-apriltags
```

이후 GitHub에서 Pull Request를 열면 됩니다.

## PR 제목 예시

```text
Add station-map AprilTag layout documentation
```

## PR 설명 예시

```text
## Summary
- Added the original apriltag_sheet.pdf used for physical marker placement
- Added station label to numeric marker ID mapping
- Documented station_map mode for WPT pair alignment
- Added Codex prompt for updating code/config from shelf convention to station_map
- Added reference YAML snippet for station_map configuration

## Notes
- The detector returns numeric marker IDs, not labels like A02N/A02E.
- For A02, west_east pair is marker IDs (8, 6).
- dry_run and safe pair-based alignment behavior should remain unchanged.
```
